import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-four',
  templateUrl: './home-four.component.html',
  styleUrls: ['./home-four.component.scss']
})
export class HomeFourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
